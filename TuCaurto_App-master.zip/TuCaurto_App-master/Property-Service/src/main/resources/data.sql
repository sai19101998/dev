insert into property_type(type,description) values('1 BHK', '1 BHK');
insert into property_type(type,description) values('2 BHK', '2 BHK');
insert into property_type(type,description) values('3 BHK', '3 BHK');
insert into property_type(type,description) values('PG','Paying Guest');
insert into users values('shivamkumar116@gmail.com','HP','Palampur',8679988179,'Male','assets/image.url','Shivam',176059,'HP');
insert into users values('ankit@gmail.com','HP','Palampur',8679988179,'Male','assets/image.url','Shivam',176059,'HP');