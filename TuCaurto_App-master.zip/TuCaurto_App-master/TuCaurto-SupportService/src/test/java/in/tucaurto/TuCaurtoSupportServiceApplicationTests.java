package in.tucaurto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuCaurtoSupportServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
