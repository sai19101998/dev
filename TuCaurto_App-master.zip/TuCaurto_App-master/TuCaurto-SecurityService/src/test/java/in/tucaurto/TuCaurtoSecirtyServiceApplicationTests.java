package in.tucaurto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuCaurtoSecirtyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
